package com.capgemini.cfs.coe.microservicetemplate.controller;
//package com.capgemini.cfs.coe.microservicetemplate.controller;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.ControllerAdvice;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.capgemini.cfs.coe.microservicetemplate.service.SpringIntializerService;
//
//@RestController
//@ControllerAdvice
//@CrossOrigin
//@RequestMapping("/api/intialize/")
//public class SpringIntializerController {
//
//	@Autowired
//	SpringIntializerService service;
//
//	Logger LOG = LoggerFactory.getLogger(getClass());
//
//	@GetMapping("/create")
//	ResponseEntity<?> CreateProject() {
//		try {
//			return service.CreateProject();
//
//		} catch (Exception e) {
//			e.printStackTrace();
//			return null; 
//
//		}
//
//
//
//	}
//
//
//}
