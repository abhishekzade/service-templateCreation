package com.capgemini.cfs.coe.microservicetemplate.config;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice;

@Component
public class Configuration {

	public static Microservice ProjectData;

	private static String PATH;

	public String getPATH() {
		return PATH;
	}

	@Value("${configurationfile}")
	public void setPath(String path) {
		PATH = path;
	}

	private static final Logger LOG = LoggerFactory.getLogger(Configuration.class);

	public static Microservice fileUnmarshaller() {
		try {
			File file = new File(PATH);
			JAXBContext jaxbContext = JAXBContext.newInstance(Microservice.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			ProjectData = (Microservice) jaxbUnmarshaller.unmarshal(file);

		} catch (JAXBException e) {
			LOG.error("Exception while parsing Node configuration XML with Exception", e);

		}
		return ProjectData;
	}
}
