package com.capgemini.cfs.coe.microservicetemplate.writer;

import java.util.ArrayList;
import java.util.List;

import javax.lang.model.element.Modifier;

import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Service;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Service.Implementations.Implementation;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Service.Implementations.Implementation.Fields.Field;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Service.Interfaces.Interface;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Service.Interfaces.Interface.Methods.Method;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Service.Interfaces.Interface.Methods.Method.Parameters;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Service.Interfaces.Interface.Methods.Method.Parameters.Parameter;
import com.capgemini.cfs.coe.microservicetemplate.util.TypeConstants;
import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.FieldSpec;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.ParameterSpec;
import com.squareup.javapoet.TypeName;
import com.squareup.javapoet.TypeSpec;

public class ServiceBuilder {


	public List<TypeSpec> getServiceClasses(Service service) {
		List<TypeSpec> serviceClasses=new ArrayList<TypeSpec>();
		for(Interface interfaceClass : service.getInterfaces().getInterface())
		{
			TypeSpec commandClass=TypeSpec.interfaceBuilder(interfaceClass.getInterfacename())
					.addModifiers(Modifier.PUBLIC)
					.addMethods(createServiceMethods(interfaceClass))
					.addAnnotation(org.springframework.stereotype.Service.class)
					.build();
			serviceClasses.add(commandClass);
		}
		for(Implementation implementation : service.getImplementations().getImplementation())
		{
			if(implementation.getImplements()!=null)
			{
				if(implementation.getFields()!=null)
				{
					TypeSpec implementaionClasses = TypeSpec.classBuilder(implementation.getClassname())
							.addModifiers(Modifier.PUBLIC)
							.addAnnotation(org.springframework.stereotype.Service.class)
							.addSuperinterface(ClassName.get("",implementation.getImplements()))
							.addMethods(addSuperInterfaceMethods(service,implementation.getImplements()))
							.addFields(createFields(implementation))
							.build();
					serviceClasses.add(implementaionClasses);
				}
				else
				{
					TypeSpec implementaionClasses = TypeSpec.classBuilder(implementation.getClassname())
							.addModifiers(Modifier.PUBLIC)
							.addAnnotation(org.springframework.stereotype.Service.class)
							.addSuperinterface(ClassName.get("",implementation.getImplements()))
							.addMethods(addSuperInterfaceMethods(service,implementation.getImplements()))
							.build();
					serviceClasses.add(implementaionClasses);
				}
			}
			else
			{
				if(implementation.getFields()!=null)
				{
					TypeSpec implementaionClasses = TypeSpec.classBuilder(implementation.getClassname())
							.addModifiers(Modifier.PUBLIC)
							.addAnnotation(org.springframework.stereotype.Service.class)
							.addFields(createFields(implementation))
							.build();
					serviceClasses.add(implementaionClasses);
				}
				else
				{
					TypeSpec implementaionClasses = TypeSpec.classBuilder(implementation.getClassname())
							.addModifiers(Modifier.PUBLIC)
							.addAnnotation(org.springframework.stereotype.Service.class)
							.build();
					serviceClasses.add(implementaionClasses);
				}
			}
		}
		return serviceClasses;
	}
	private Iterable<MethodSpec> addSuperInterfaceMethods(Service service, String implementationClass) {
		List<MethodSpec> methodSpecs = new ArrayList<MethodSpec>();
		for(Interface interface1 : service.getInterfaces().getInterface())
		{
			if(interface1.getInterfacename().equalsIgnoreCase(implementationClass))
			{
				if(interface1.getMethods()!=null && interface1.getMethods().getMethod()!=null)
				{
					for(Method method : interface1.getMethods().getMethod())
					{
						methodSpecs.add(
								MethodSpec.methodBuilder(method.getName())
								.addModifiers(Modifier.PUBLIC)
								.addAnnotation(Override.class)
								.addParameters(getParameters(method.getParameters()))
								.addStatement("// TODO Auto-generated method stub")
								.addStatement("return null")
								.returns(TypeConstants.getType(method.getReturns()))
								.build());
					}
				}
			}
		}

		return methodSpecs;
	}
	private Iterable<MethodSpec> createServiceMethods(Interface interfaceClass) {
		List<MethodSpec> methodSpecs = new ArrayList<MethodSpec>();
		if(interfaceClass.getMethods()!=null)
		{
			for(Method method : interfaceClass.getMethods().getMethod())
			{

				methodSpecs.add(MethodSpec.methodBuilder(method.getName())
						.addModifiers(Modifier.PUBLIC, Modifier.ABSTRACT)
						.addParameters(getParameters(method.getParameters()))
						.returns(TypeConstants.getType(method.getReturns()))
						.build()
						);
			}
		}
		return methodSpecs;
	}

	private Iterable<ParameterSpec> getParameters(Parameters parameters) {
		List<ParameterSpec> methodParams=new ArrayList<ParameterSpec>();
		if(parameters != null && parameters.getParameter()!=null)
		{
			for(Parameter param:parameters.getParameter())
			{
				TypeName modelName=TypeConstants.getType(param.getType());
				methodParams.add(ParameterSpec.builder(modelName,param.getName())
						.build());
			}
		}

		return methodParams;
	}
	private Iterable<FieldSpec> createFields(Implementation implementation) {
		List<FieldSpec> fieldSpecs = new ArrayList<FieldSpec>();
		for(Field field : implementation.getFields().getField())
		{
			fieldSpecs.add(
					FieldSpec.builder(TypeConstants.getServiceClasses(field.getType()), field.getName(), TypeConstants.getModifier(field.getModifier()))
					.addAnnotation(TypeConstants.getAnnotationType(field.getAnnotation()))
					.build());
		}
		return fieldSpecs;
	}
}
