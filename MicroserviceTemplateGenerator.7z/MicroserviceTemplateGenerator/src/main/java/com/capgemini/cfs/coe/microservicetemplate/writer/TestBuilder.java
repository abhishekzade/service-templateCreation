package com.capgemini.cfs.coe.microservicetemplate.writer;

import java.util.ArrayList;
import java.util.List;

import javax.lang.model.element.Modifier;

import org.junit.Before;
import org.mockito.InjectMocks;

import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Tests;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Controllers.Controller;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Service.Implementations.Implementation;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Tests.Test;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Tests.Test.Methods.Method;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Tests.Test.Methods.Method.Parameters;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Tests.Test.Methods.Method.Parameters.Parameter;
import com.capgemini.cfs.coe.microservicetemplate.util.TypeConstants;
import com.squareup.javapoet.AnnotationSpec;
import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.FieldSpec;
import com.squareup.javapoet.JavaFile;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.ParameterSpec;
import com.squareup.javapoet.TypeName;
import com.squareup.javapoet.TypeSpec;

import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.PactVerification;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.model.RequestResponsePact;

public class TestBuilder {

	public List<TypeSpec> getTestClasses(Tests tests) {

		List<TypeSpec> testClasses = new ArrayList<TypeSpec>();
		for (Test test : tests.getTest()) {
			if (test.getMethods() != null) {
				TypeSpec testClass = TypeSpec.classBuilder(test.getClassname()).addModifiers(Modifier.PUBLIC)
						.addMethods(createTestMethods(test)).build();
				testClasses.add(testClass);
			} else {
				TypeSpec testClass = TypeSpec.classBuilder(test.getClassname()).addModifiers(Modifier.PUBLIC).build();
				testClasses.add(testClass);
			}
			testClasses.add(TypeSpec.classBuilder("SampleContractTests").addModifiers(Modifier.PUBLIC)
					.addMethods(addDefaultTestMethods("SampleContractTests")).build());
		}

		return testClasses;
	}

	private Iterable<MethodSpec> addDefaultTestMethods(String className) {
		List<MethodSpec> methodsList = new ArrayList<MethodSpec>();
		if (className.equalsIgnoreCase("SampleContractTests")) {
			MethodSpec repoMethod = MethodSpec.methodBuilder("createFragment").addModifiers(Modifier.PUBLIC)
					.addAnnotation(AnnotationSpec.builder(Pact.class).addMember("provider", "$S", "test_provider")
							.addMember("consumer", "$S", "test_consumer").build())
					.returns(RequestResponsePact.class)
					.addParameter(ParameterSpec.builder(PactDslWithProvider.class, "event").build())
					.addStatement("/* Code to be added */\r\n" + "		/*Sample Code---------\r\n"
							+ "		 * .given(\"Test Savings\").uponReceiving(\"Testing Savings Account Service\").path(\"/api/savings\").method(\"POST\").headers(headers)\r\n"
							+ "				.body(\"{\\n\" + \r\n"
							+ "						\"  \\\"accountNumber\\\": \\\"98765432\\\",\\n\" + \r\n"
							+ "						\"  \\\"accountName\\\": \\\"Ben\\\",\\n\" + \r\n"
							+ "						\"  \\\"minimumAccountsList\\\": 1,\\n\" + \r\n"
							+ "						\"  \\\"fixedDepositList\\\": {\\n\" + \r\n"
							+ "						\"    \\\"fdid\\\" : [\\n\" + \r\n"
							+ "						\"      \\\"0123456\\\"\\n\" + \r\n"
							+ "						\"    ]\\n\" + \r\n" + "						\"  }\\n\" + \r\n"
							+ "						\"}\")\r\n" + "				.willRespondWith()\r\n"
							+ "				.status(200).headers(headers)\r\n"
							+ "				.body(\"{\" + \"  \\\"status\\\": \\\"0\\\",\\n\" + \"  \\\"message\\\": \\\"Request Completed Successfully\\\"}\")\r\n"
							+ "				.given(\"Test Current\").uponReceiving(\"Testing Current Account Service\").path(\"/api/currentaccounts\").method(\"POST\").headers(headers)\r\n"
							+ "				.body(\"{\\n\" + \r\n"
							+ "						\"  \\\"accountNumber\\\": \\\"98765432\\\",\\n\" + \r\n"
							+ "						\"  \\\"accountName\\\": \\\"John\\\",\\n\" + \r\n"
							+ "						\"  \\\"currentAccountList\\\": {\\n\" + \r\n"
							+ "						\"    \\\"currentAccount\\\": [\\n\" + \r\n"
							+ "						\"      {\\n\" + \r\n"
							+ "						\"        \\\"accountBusinessId\\\" : \\\"A123987\\\",\\n\" + \r\n"
							+ "						\"        \\\"accountNumber\\\": \\\"23454312\\\",\\n\" + \r\n"
							+ "						\"        \\\"accountName\\\": \\\"John Weasly\\\",\\n\" + \r\n"
							+ "						\"        \\\"accountType\\\": \\\"Business\\\"\\n\" + \r\n"
							+ "						\"      }\\n\" + \r\n" + "						\"    ]\\n\" + \r\n"
							+ "						\"  }\\n\" + \r\n" + "						\"}\")\r\n"
							+ "				.willRespondWith()\r\n" + "				.status(200).headers(headers)\r\n"
							+ "				.body(\"{\" + \"  \\\"status\\\": \\\"0\\\",\\n\" + \"  \\\"message\\\": \\\"Request Completed Successfully\\\"}\")\r\n"
							+ "				.toPact();\r\n" + "		 * \r\n" + "		 */")
					.addStatement("return null").build();
			methodsList.add(repoMethod);
			MethodSpec testMethod = MethodSpec.methodBuilder("runTest").addModifiers(Modifier.PUBLIC)
					.returns(TypeName.VOID).addAnnotation(org.junit.Test.class)
					.addStatement("// Add your own test implementation logic").addAnnotation(AnnotationSpec
							.builder(PactVerification.class).addMember("value", "$S", "test_provider").build())
					.build();
			methodsList.add(testMethod);
		} else if (className.equalsIgnoreCase("ServiceTemplateTests")) {
			MethodSpec repoMethod = MethodSpec.methodBuilder("contextLoads").addModifiers(Modifier.PUBLIC)
					.returns(TypeName.VOID).addAnnotation(org.junit.Test.class)
					.addStatement("// TODO Auto-generated method stub").build();
			methodsList.add(repoMethod);
		}
		return methodsList;
	}

	private Iterable<MethodSpec> createTestMethods(Test test) {
		List<MethodSpec> methodsList = new ArrayList<MethodSpec>();
		for (Method method : test.getMethods().getMethod()) {
			if (method.getParameters() != null) {
				MethodSpec repoMethod = MethodSpec.methodBuilder(method.getName().toString())
						.addModifiers(Modifier.PUBLIC).returns(TypeConstants.getType(method.getReturns()))
						.addParameters(createParameters(method.getParameters()))
						.addStatement("// TODO Auto-generated method stub").addStatement("return null").build();
				methodsList.add(repoMethod);
			} else {
				MethodSpec repoMethod = MethodSpec.methodBuilder(method.getName()).addModifiers(Modifier.PUBLIC)
						.returns(TypeConstants.getType(method.getReturns()))
						.addStatement("// TODO Auto-generated method stub").addStatement("return null").build();
				methodsList.add(repoMethod);
			}
		}

		return methodsList;
	}

	private Iterable<ParameterSpec> createParameters(Parameters parameters) {
		List<ParameterSpec> parameterSpecs = new ArrayList<ParameterSpec>();
		for (Parameter parameter : parameters.getParameter()) {
			ParameterSpec parameterSpec = ParameterSpec
					.builder(TypeConstants.getType(parameter.getType()), parameter.getName()).build();
			parameterSpecs.add(parameterSpec);
		}
		return parameterSpecs;
	}

	public List<JavaFile> addTestClasses(Microservice projectData) {

		List<JavaFile> javaFiles = new ArrayList<JavaFile>();

		if (projectData.getControllers() != null && projectData.getControllers().getController() != null) {
			for (Controller controller : projectData.getControllers().getController()) {
				if (controller.getClassname() != null) {
					javaFiles.add(JavaFile
							.builder(projectData.getBasePackage() + "." + projectData.getControllers().getPackagename(),
									getTestClass(controller.getClassname()))
							.build());
				}
			}
		}

		if (projectData.getService() != null && projectData.getService().getImplementations() != null
				&& projectData.getService().getImplementations().getImplementation() != null) {
			for (Implementation implementation : projectData.getService().getImplementations().getImplementation()) {
				if (implementation.getClassname() != null) {
					javaFiles.add(JavaFile
							.builder(projectData.getBasePackage() + "." + projectData.getService().getPackagename(),
									getTestClass(implementation.getClassname()))
							.build());
				}
			}
		}
		if (projectData.getBackendIntegration() != null && projectData.getBackendIntegration().getDao() != null
				&& projectData.getBackendIntegration().getDao().getImplementations() != null
				&& projectData.getBackendIntegration().getDao().getImplementations().getImplementation() != null) {
			for (com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Dao.Implementations.Implementation implementation : projectData
					.getBackendIntegration().getDao().getImplementations().getImplementation()) {
				if (implementation.getClassname() != null) {
					javaFiles.add(JavaFile.builder(
							projectData.getBasePackage() + "."
									+ projectData.getBackendIntegration().getDao().getPackagename(),
							getTestClass(implementation.getClassname())).build());
				}
			}
		}

		if (projectData.getBackendIntegration() != null && projectData.getBackendIntegration().getMessaging() != null
				&& projectData.getBackendIntegration().getMessaging().getImplementations() != null && projectData
						.getBackendIntegration().getMessaging().getImplementations().getImplementation() != null) {
			for (com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Implementations.Implementation implementation : projectData
					.getBackendIntegration().getMessaging().getImplementations().getImplementation()) {
				if (implementation.getClassname() != null) {
					javaFiles
							.add(JavaFile
									.builder(
											projectData.getBasePackage() + "."
													+ projectData.getBackendIntegration().getMessaging()
															.getPackagename(),
											getTestClass(implementation.getClassname()))
									.build());
				}
			}
		}

		return javaFiles;
	}

	private TypeSpec getTestClass(String classname) {

		TypeSpec testClass = TypeSpec.classBuilder(classname + "Tests").addModifiers(Modifier.PUBLIC)
				.addField(FieldSpec.builder(ClassName.get("", classname), classname.toLowerCase(), Modifier.PRIVATE)
						.addAnnotation(InjectMocks.class).build())
				.addMethods(addDefaultTestMethods()).build();

		return testClass;
	}

	private Iterable<MethodSpec> addDefaultTestMethods() {
		List<MethodSpec> methodsList = new ArrayList<MethodSpec>();

		MethodSpec beforeMethod = MethodSpec.methodBuilder("before").addModifiers(Modifier.PUBLIC)
				.addAnnotation(Before.class).addStatement("// TODO Auto-generated method stub").build();
		methodsList.add(beforeMethod);

		MethodSpec successMethod = MethodSpec.methodBuilder("testSuccess").addModifiers(Modifier.PUBLIC)
				.addAnnotation(org.junit.Test.class).addStatement("// TODO Auto-generated method stub").build();
		methodsList.add(successMethod);

		MethodSpec failureMethod = MethodSpec.methodBuilder("testFailure").addModifiers(Modifier.PUBLIC)
				.addAnnotation(org.junit.Test.class).addStatement("// TODO Auto-generated method stub").build();
		methodsList.add(failureMethod);

		return methodsList;
	}

}
