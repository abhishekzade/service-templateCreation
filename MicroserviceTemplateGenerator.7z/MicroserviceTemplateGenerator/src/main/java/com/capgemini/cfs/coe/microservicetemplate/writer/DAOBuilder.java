package com.capgemini.cfs.coe.microservicetemplate.writer;

import java.util.ArrayList;
import java.util.List;

import javax.lang.model.element.Modifier;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Dao;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Dao.Databases;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Dao.Databases.Database;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Dao.Databases.Database.Repositories.Repository;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Dao.Implementations.Implementation;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Dao.Implementations.Implementation.Fields.Field;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Dao.Interfaces.Interface;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Dao.Interfaces.Interface.Methods.Method;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Dao.Interfaces.Interface.Methods.Method.Parameters;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Dao.Interfaces.Interface.Methods.Method.Parameters.Parameter;
import com.capgemini.cfs.coe.microservicetemplate.util.TypeConstants;
import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.FieldSpec;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.ParameterSpec;
import com.squareup.javapoet.ParameterizedTypeName;
import com.squareup.javapoet.TypeName;
import com.squareup.javapoet.TypeSpec;

public class DAOBuilder {


	public List<TypeSpec> getServiceClasses(Dao dao) {
		List<TypeSpec> daoClasses=new ArrayList<TypeSpec>();
		for(Interface interfaceClass : dao.getInterfaces().getInterface())
		{
			TypeSpec daoClass=TypeSpec.interfaceBuilder(interfaceClass.getInterfacename())
					.addModifiers(Modifier.PUBLIC)
					.addAnnotation(org.springframework.stereotype.Service.class)
					.addMethods(createDaoMethods(interfaceClass))
					.build();
			daoClasses.add(daoClass);
		}
		for(Implementation implementation : dao.getImplementations().getImplementation())
		{
			if(implementation.getImplements()!=null)
			{
				if(implementation.getFields()!=null)
				{
					TypeSpec implementaionClasses = TypeSpec.classBuilder(implementation.getClassname())
							.addModifiers(Modifier.PUBLIC)
							.addAnnotation(org.springframework.stereotype.Service.class)
							.addFields(createFields(implementation))
							.addSuperinterface(ClassName.get("",implementation.getImplements()))
							.addMethods(addSuperInterfaceMethods(dao,implementation.getImplements()))
							.build();
					daoClasses.add(implementaionClasses);
				}
				else
				{
					TypeSpec implementaionClasses = TypeSpec.classBuilder(implementation.getClassname())
							.addModifiers(Modifier.PUBLIC)
							.addAnnotation(org.springframework.stereotype.Service.class)
							.addSuperinterface(ClassName.get("",implementation.getImplements()))
							.addMethods(addSuperInterfaceMethods(dao,implementation.getImplements()))
							.build();
					daoClasses.add(implementaionClasses);
				}
			}
			else
			{
				if(implementation.getFields()!=null)
				{
					TypeSpec implementaionClasses = TypeSpec.classBuilder(implementation.getClassname())
							.addModifiers(Modifier.PUBLIC)
							.addAnnotation(org.springframework.stereotype.Service.class)
							.addFields(createFields(implementation))
							.build();
					daoClasses.add(implementaionClasses);
				}
				else
				{
					TypeSpec implementaionClasses = TypeSpec.classBuilder(implementation.getClassname())
							.addModifiers(Modifier.PUBLIC)
							.addAnnotation(org.springframework.stereotype.Service.class)
							.build();
					daoClasses.add(implementaionClasses);
				}
			}
		}
		return daoClasses;
	}

	private Iterable<MethodSpec> addSuperInterfaceMethods(Dao dao, String implements1) {
		List<MethodSpec> methodSpecs = new ArrayList<MethodSpec>();
		for(Interface interface1 : dao.getInterfaces().getInterface())
		{
			if(interface1.getInterfacename().equalsIgnoreCase(implements1))
			{
				if(interface1.getMethods()!=null && interface1.getMethods().getMethod()!=null)
				{
					for(Method method : interface1.getMethods().getMethod())
					{
						methodSpecs.add(
								MethodSpec.methodBuilder(method.getName())
								.addModifiers(Modifier.PUBLIC)
								.addAnnotation(Override.class)
								.addParameters(getParameters(method.getParameters()))
								.addStatement("// TODO Auto-generated method stub")
								.addStatement("return null")
								.returns(TypeConstants.getType(method.getReturns()))
								.build());
					}
				}
			}
		}

		return methodSpecs;
	}

	private Iterable<MethodSpec> createDaoMethods(Interface interfaceClass) {
		List<MethodSpec> methodSpecs = new ArrayList<MethodSpec>();
		if(interfaceClass.getMethods()!=null)
		{
			for(Method method : interfaceClass.getMethods().getMethod())
			{

				methodSpecs.add(MethodSpec.methodBuilder(method.getName())
						.addModifiers(Modifier.PUBLIC, Modifier.ABSTRACT)
						.addParameters(getParameters(method.getParameters()))
						.returns(TypeConstants.getType(method.getReturns()))
						.build()
						);
			}
		}
		return methodSpecs;
	}

	private Iterable<ParameterSpec> getParameters(Parameters parameters) {
		List<ParameterSpec> methodParams=new ArrayList<ParameterSpec>();
		if(parameters != null && parameters.getParameter()!=null)
		{
			for(Parameter param:parameters.getParameter())
			{
				TypeName modelName=TypeConstants.getType(param.getType());
				methodParams.add(ParameterSpec.builder(modelName,param.getName())
						.build());
			}
		}

		return methodParams;
	}

	private Iterable<FieldSpec> createFields(Implementation implementation) {
		List<FieldSpec> fieldSpecs = new ArrayList<FieldSpec>();
		for(Field field : implementation.getFields().getField())
		{
			fieldSpecs.add(
					FieldSpec.builder(TypeConstants.getDAOClasses(field.getType()), field.getName(), TypeConstants.getModifier(field.getModifier()))
					.addAnnotation(TypeConstants.getAnnotationType(field.getAnnotation()))
					.build());
		}
		return fieldSpecs;
	}

	public List<TypeSpec> getDataBaseClasses(Databases databases) {
		List<TypeSpec> databaseClasses=new ArrayList<TypeSpec>();
		for(Database database :  databases.getDatabase())
		{
			if(database.getRepositories()!=null)
			{
				if(database.getType().equalsIgnoreCase("MongoDataBase"))
				{
					for(Repository repository : database.getRepositories().getRepository())
					{
						TypeName name = ParameterizedTypeName.get(ClassName.get(MongoRepository.class),TypeConstants.getType(repository.getModelname()),TypeConstants.getType(repository.getIdtype()));
						TypeSpec databaseClass=TypeSpec.interfaceBuilder(repository.getName())
								.addSuperinterface(name)
								.addModifiers(Modifier.PUBLIC)
								.addAnnotation(org.springframework.stereotype.Service.class)
								.addMethods(addRepositoryMethods(repository))
								.build();
						databaseClasses.add(databaseClass);
					}
				}
			}
		}
		return databaseClasses;
	}

	private Iterable<MethodSpec> addRepositoryMethods(Repository repository) {
		List<MethodSpec> methodSpecs = new ArrayList<MethodSpec>();
		if(repository.getMethods()!=null && repository.getMethods().getMethod()!=null)
		{
			for(com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Dao.Databases.Database.Repositories.Repository.Methods.Method method : repository.getMethods().getMethod())
			{

				methodSpecs.add(MethodSpec.methodBuilder(method.getName())
						.addModifiers(Modifier.PUBLIC,Modifier.ABSTRACT)
						.addParameters(repositoryMethodParameters(method.getParameters()))
						.returns(TypeConstants.getType(method.getReturns()))
						.build()
						);
			}
		}
		return methodSpecs;
	}

	private Iterable<ParameterSpec> repositoryMethodParameters(
			com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Dao.Databases.Database.Repositories.Repository.Methods.Method.Parameters parameters)
	{
		List<ParameterSpec> methodParams=new ArrayList<ParameterSpec>();
		if(parameters != null && parameters.getParameter()!=null)
		{
			for(com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Dao.Databases.Database.Repositories.Repository.Methods.Method.Parameters.Parameter param:parameters.getParameter())
			{
				TypeName modelName=TypeConstants.getType(param.getType());
				methodParams.add(ParameterSpec.builder(modelName,param.getName())
						.build());
			}
		}

		return methodParams;
	}
}
