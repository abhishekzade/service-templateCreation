package com.capgemini.cfs.coe.microservicetemplate.service;

//import java.io.IOException;
//
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Component;
//
//@Component
//public interface SpringIntializerService {
//	
//	ResponseEntity<String> CreateProject() throws IOException, Exception;
//
//}
