package com.capgemini.cfs.coe.microservicetemplate.writer;

import org.springframework.web.bind.annotation.ControllerAdvice;

import com.squareup.javapoet.TypeSpec;

public class ExceptionBuilder {

	public TypeSpec getExceptionHandlingClass() {

		TypeSpec exceptionHandlingClass = TypeSpec.classBuilder("GlobalExceptionHandler")
				.addAnnotation(ControllerAdvice.class)
				.superclass(RuntimeException.class)
				.build();

		return exceptionHandlingClass;
	}

}
