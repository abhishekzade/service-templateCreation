package com.capgemini.cfs.coe.microservicetemplate.util;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.lang.model.element.Modifier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.cfs.coe.microservicetemplate.config.Configuration;
import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.ParameterizedTypeName;
import com.squareup.javapoet.TypeName;

public class TypeConstants {

	public static String BASE_PACKAGE = Configuration.ProjectData.getBasePackage();
	public static String SERVICE_PACKAGE = BASE_PACKAGE + ".service";
	public static String DAO_PACKAGE = BASE_PACKAGE + ".dao";
	public static String EVENT_PACKAGE = BASE_PACKAGE + ".event";
	public static String CNFIG_PACKAGE = BASE_PACKAGE + ".config";
	public static String CONTROLLER_PACKAGE = BASE_PACKAGE + ".controller";
	public static String HANDLER_PACKAGE = BASE_PACKAGE + ".handler";
	public static String EXCEPTION_PACKAGE = ".exception";
	public static String RESOURCES_FOLDER = "src//main//resources//";
	public static String MODEL_PACKAGE = BASE_PACKAGE + ".model";
	public static String[] RESOURCE_FILES = { "checkstyle.xml", "suppressions.xml", "logback.xml"};

	public static TypeName getType(String name) {
		switch (name.toLowerCase()) {
		case "string":
			return TypeName.get(String.class);
		case "bigdecimal":
			return TypeName.get(BigDecimal.class);
		case "list":
			return ParameterizedTypeName.get(List.class, Object.class);
		case "map":
			return ParameterizedTypeName.get(Map.class, Object.class, Object.class);
		case "integer":
			return TypeName.get(int.class);
		case "long":
			return TypeName.get(Long.class);
		case "short":
			return TypeName.get(Short.class);
		case "double":
			return TypeName.get(Double.class);
		case "float":
			return TypeName.get(Float.class);
		case "mongotemplate":
			return ClassName.get(MongoTemplate.class);
		default:
			return ClassName.get(MODEL_PACKAGE, name);
		}
	}

	public static TypeName getDAOClasses(String name) {
		switch (name.toLowerCase()) {
		case "string":
			return TypeName.get(String.class);
		case "bigdecimal":
			return TypeName.get(BigDecimal.class);
		case "list":
			return ParameterizedTypeName.get(List.class, Object.class);
		case "map":
			return ParameterizedTypeName.get(Map.class, Object.class, Object.class);
		case "integer":
			return TypeName.get(int.class);
		case "long":
			return TypeName.get(Long.class);
		case "short":
			return TypeName.get(Short.class);
		case "double":
			return TypeName.get(Double.class);
		case "float":
			return TypeName.get(Float.class);
		case "kafkatemplate":
			return TypeName.get(KafkaTemplate.class);
		case "mongotemplate":
			return ClassName.get(MongoTemplate.class);
		default:
			return ClassName.get(DAO_PACKAGE, name);
		}
	}

	public static TypeName getServiceClasses(String name) {
		switch (name.toLowerCase()) {
		case "string":
			return TypeName.get(String.class);
		case "bigdecimal":
			return TypeName.get(BigDecimal.class);
		case "list":
			return ParameterizedTypeName.get(List.class, Object.class);
		case "map":
			return ParameterizedTypeName.get(Map.class, Object.class, Object.class);
		case "integer":
			return TypeName.get(int.class);
		case "long":
			return TypeName.get(Long.class);
		case "short":
			return TypeName.get(Short.class);
		case "double":
			return TypeName.get(Double.class);
		case "float":
			return TypeName.get(Float.class);
		case "mongotemplate":
			return ClassName.get(MongoTemplate.class);
		default:
			return ClassName.get(DAO_PACKAGE, name);
		}
	}

	public static Modifier getModifier(String name) {
		switch (name) {
		case "public":
			return Modifier.PUBLIC;
		case "private":
			return Modifier.PRIVATE;
		case "protected":
			return Modifier.PROTECTED;
		default:
			return Modifier.DEFAULT;
		}
	}

	public static ClassName getAnnotationType(String name) {
		switch (name) {
		case "POST":
			return ClassName.get(PostMapping.class);
		case "GET":
			return ClassName.get(GetMapping.class);
		case "PUT":
			return ClassName.get(PutMapping.class);
		case "DELETE":
			return ClassName.get(DeleteMapping.class);
		case "PATCH":
			return ClassName.get(PatchMapping.class);
		case "RequestBody":
			return ClassName.get(RequestBody.class);
		case "PathVariable":
			return ClassName.get(PathVariable.class);
		case "RequestParam":
			return ClassName.get(RequestParam.class);
		case "Autowired":
			return ClassName.get(Autowired.class);
		case "KafkaListener":
			return ClassName.get(KafkaListener.class);
		default:
			return null;
		}
	}

}
