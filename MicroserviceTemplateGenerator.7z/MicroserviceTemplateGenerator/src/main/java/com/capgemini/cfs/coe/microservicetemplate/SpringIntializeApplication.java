package com.capgemini.cfs.coe.microservicetemplate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.capgemini.cfs.coe.microservicetemplate.service.SpringIntializerServiceImpl;

@SpringBootApplication
//@EnableAutoConfiguration
//@ComponentScan(basePackages = {"com.capgemini.cfs.coe.microservicetemplate"})
public class SpringIntializeApplication {
	
	public static void main(String[] args) throws Exception {
		SpringApplication.run(SpringIntializeApplication.class, args);
		SpringIntializerServiceImpl impl = new SpringIntializerServiceImpl();
		impl.CreateProject();
	}
	
}
