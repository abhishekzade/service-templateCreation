package com.capgemini.cfs.coe.microservicetemplate.writer;

import java.util.ArrayList;
import java.util.List;

import javax.lang.model.element.Modifier;

import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Models;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Models.Model;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Models.Model.Attributes;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Models.Model.Attributes.Attribute;
import com.capgemini.cfs.coe.microservicetemplate.util.TypeConstants;
import com.squareup.javapoet.FieldSpec;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.TypeSpec;

public class ModelBuilder {


	public List<TypeSpec> getModelClasses(Models models) {
		List<TypeSpec> modelClasses=new ArrayList<TypeSpec>();
		for(Model model:models.getModel())
		{
			if(model.getAttributes()!=null) 
			{
				modelClasses.add(TypeSpec.classBuilder(model.getClassname())
						.addModifiers(Modifier.PUBLIC)
						.addFields(getModelFields(model.getAttributes()))
						.addMethods(getGetterSetterMethods(model.getAttributes()))
						.addMethod(MethodSpec.constructorBuilder().addModifiers(Modifier.PUBLIC).build())
						.build());
			}
			else
			{
				modelClasses.add(TypeSpec.classBuilder(model.getClassname())
						.addModifiers(Modifier.PUBLIC)
						.build());
			}
		}
		return modelClasses;
	}

	private Iterable<MethodSpec> getGetterSetterMethods(Attributes attributes) {
		List<MethodSpec> methodList=new ArrayList<MethodSpec>();
		for(Attribute attribute :attributes.getAttribute())
		{
			String methodName = Character.toUpperCase(attribute.getName().charAt(0)) + attribute.getName().substring(1);
			MethodSpec settermethodSpec=  MethodSpec.methodBuilder("set" + methodName)
					.addModifiers(Modifier.PUBLIC)
					.addParameter(TypeConstants.getType(attribute.getType()), attribute.getName())
					.returns(void.class)
					.addStatement("this.$L = $L", attribute.getName(), attribute.getName())
					.build();
			methodList.add(settermethodSpec);
			MethodSpec getterMethodSpec= MethodSpec.methodBuilder("get" + methodName)
					.addModifiers(Modifier.PUBLIC)
					.returns(TypeConstants.getType(attribute.getType()))
					.addStatement("return $L", attribute.getName())
					.build();
			methodList.add(getterMethodSpec);
		}
		return methodList;


	}

	private Iterable<FieldSpec> getModelFields(Attributes attributes) {
		List<FieldSpec> fields=new ArrayList<FieldSpec>();
		for(Attribute field:attributes.getAttribute())
		{
			fields.add(FieldSpec.builder(TypeConstants.getType(field.getType()), field.getName(), Modifier.PRIVATE).build());
		}
		return fields;
	}



}
