package com.capgemini.cfs.coe.microservicetemplate.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.maven.model.Model;
import org.apache.maven.model.io.xpp3.MavenXpp3Reader;
import org.apache.maven.model.io.xpp3.MavenXpp3Writer;
import org.codehaus.plexus.util.xml.pull.XmlPullParserException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.capgemini.cfs.coe.microservicetemplate.config.Configuration;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.ExternalDependencies;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.ProjectSpringDependencies;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Properties.Property;
import com.capgemini.cfs.coe.microservicetemplate.util.TypeConstants;
import com.capgemini.cfs.coe.microservicetemplate.writer.ConfigurationBuilder;
import com.capgemini.cfs.coe.microservicetemplate.writer.ControllerBuilder;
import com.capgemini.cfs.coe.microservicetemplate.writer.DAOBuilder;
import com.capgemini.cfs.coe.microservicetemplate.writer.ExceptionBuilder;
import com.capgemini.cfs.coe.microservicetemplate.writer.MessageBuilder;
import com.capgemini.cfs.coe.microservicetemplate.writer.ModelBuilder;
import com.capgemini.cfs.coe.microservicetemplate.writer.ServiceBuilder;
import com.capgemini.cfs.coe.microservicetemplate.writer.TestBuilder;
import com.squareup.javapoet.JavaFile;
import com.squareup.javapoet.TypeSpec;

@Service
public class SpringIntializerServiceImpl {
	Logger LOG = LoggerFactory.getLogger(getClass());

	private static String configurationFilePath;

	public String getConfigurationFilePath() {
		return configurationFilePath;
	}

	@Value("${configurationfile}")
	public void setConfigurationFilePath(String configurationPath) {
		configurationFilePath = configurationPath;
	}

	public void CreateProject() throws Exception {
		Microservice projectData = Configuration.fileUnmarshaller();
		String JavaFilePath = Configuration.ProjectData.getProjectcreationpath() + "\\"
				+ Configuration.ProjectData.getProjectName() + "\\src\\main\\java\\";
		String ResourcesPath = Configuration.ProjectData.getProjectcreationpath() + "\\"
				+ Configuration.ProjectData.getProjectName() + "\\src\\main\\resources\\";
		String testClassesPath = Configuration.ProjectData.getProjectcreationpath() + "\\"
				+ Configuration.ProjectData.getProjectName() + "\\src\\test\\java\\";
		TypeConstants.BASE_PACKAGE = projectData.getBasePackage();

		List<JavaFile> JavaFiles = buildJavaClasses(projectData);

		for (JavaFile file : JavaFiles) {
			file.writeTo(new File(JavaFilePath));
		}
		List<JavaFile> javaTestFiles = buildJavaTestClasses(projectData);
		for (JavaFile file : javaTestFiles) {
			file.writeTo(new File(testClassesPath));
		}

		addCommandPropertiesFile(ResourcesPath, projectData);
		addResourceFiles(ResourcesPath,projectData);
		addFiles(projectData);
		addExternalDependenciesAndProperties(projectData);
		addPlugins(projectData);
		System.exit(0);
	}


	private void addFiles(Microservice projectData) throws Exception {

		try {
			File file = new File(Configuration.ProjectData.getProjectcreationpath() + "\\"
					+ Configuration.ProjectData.getProjectName() + "\\Dockerfile");
			ClassLoader classLoader = getClass().getClassLoader();
			InputStream input = classLoader.getResourceAsStream("Dockerfile");
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(input));
			FileWriter fileWriter = new FileWriter(file);
			String fileData;

			File sourceFolder = new File("wiremock-standalone");
			File destinationFolder = new File(Configuration.ProjectData.getProjectcreationpath() + "\\"
					+ Configuration.ProjectData.getProjectName() + "\\" + "wiremock-standalone");
			FileUtils.copyDirectory(sourceFolder, destinationFolder);
			while ((fileData = bufferedReader.readLine()) != null) {
				if (fileData.contains("$")) {
					fileData = fileData.replace("$", projectData.getProjectName());
				}
				fileWriter.write(fileData);
				fileWriter.write(System.getProperty("line.separator"));
				fileWriter.flush();
			}
			bufferedReader.close();
			fileWriter.close();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new Exception("Exception Occured While adding files");
		}

	}

	private List<JavaFile> buildJavaTestClasses(Microservice projectData) {
		List<JavaFile> javaFiles = new ArrayList<JavaFile>();

		TestBuilder testBuilder = new TestBuilder();
		javaFiles.addAll(testBuilder.addTestClasses(projectData));

		return javaFiles;
	}

	private void addResourceFiles(String resourcesPath, Microservice projectData) throws Exception {
		try {
			for (String fileName : TypeConstants.RESOURCE_FILES) {
				File file = new File(resourcesPath + fileName);
				ClassLoader classLoader = getClass().getClassLoader();
				InputStream input = classLoader.getResourceAsStream(fileName);
				BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(input));
				FileWriter fileWriter = new FileWriter(file);
				String fileData;

				while ((fileData = bufferedReader.readLine()) != null) {
					if(fileName.equalsIgnoreCase("logback.xml") && fileData.contains("$PackageName"))
					{
						fileData = "<layout class=\""+projectData.getBasePackage()+"."+projectData.getConfigurations().getPackagename()+".LogConfig"+"\">";
					}
					fileWriter.write(fileData);
					fileWriter.write(System.getProperty("line.separator"));
					fileWriter.flush();
				}
				bufferedReader.close();
				fileWriter.close();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new Exception("Exception Occured While adding resource files");
		}

	}

	private void addPlugins(Microservice projectData) throws Exception
	{
		try {

			FileReader fileReader = new FileReader(Configuration.ProjectData.getProjectcreationpath()+"//"+projectData.getProjectName()+"//pom.xml");
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			FileReader fileReader1 = new FileReader(configurationFilePath);
			BufferedReader bufferedReader1 = new BufferedReader(fileReader1);
			String pomFile = Configuration.ProjectData.getProjectcreationpath()+"//"+projectData.getProjectName()+"//pom.xml";
			String filename = Configuration.ProjectData.getProjectcreationpath()+"//"+projectData.getProjectName()+"//temp.xml";
			BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(filename));
			String fileData, fileData1;
			while ((fileData = bufferedReader.readLine()) != null) { 
				if(fileData.contains("<plugins>"))
				{
					while ((fileData1 = bufferedReader1.readLine()) != null) { 
						if(fileData1.contains("<plugins>"))
						{
							bufferedWriter.write("<plugins>");
							while ((fileData1 = bufferedReader1.readLine()) != null) { 
								if(!fileData1.contains("</plugins>"))
									bufferedWriter.write(fileData1+"\n");
								if(fileData1.contains("</plugins>"))
									break;
							}
						}
					}
				}else
				{
					bufferedWriter.write(fileData+"\n");
				}
			}
			bufferedWriter.close();
			bufferedReader.close();
			bufferedReader1.close();
			fileReader.close();
			fileReader1.close();
			File file = new File(pomFile); 
			file.delete();
			File newFile = new File(filename);
			newFile.renameTo(file);
		} catch (Exception ex) { 
			ex.printStackTrace();
			throw new Exception("Exception Occured While adding Plugins"); 
		}
	}

	private void addExternalDependenciesAndProperties(Microservice projectData)
			throws IOException, XmlPullParserException {
		File pomFile = new File(
				Configuration.ProjectData.getProjectcreationpath() + "//" + projectData.getProjectName() + "//pom.xml");
		Reader reader;
		Writer writer = null;
		reader = new FileReader(pomFile);
		final Model model;
		try {
			final MavenXpp3Reader xpp3Reader = new MavenXpp3Reader();
			model = xpp3Reader.read(reader);
			for (ExternalDependencies.Dependency dependency : projectData.getExternalDependencies().getDependency()) {
				org.apache.maven.model.Dependency mavenDependency = new org.apache.maven.model.Dependency();
				mavenDependency.setArtifactId(dependency.getArtifactId());
				mavenDependency.setGroupId(dependency.getGroupId());
				mavenDependency.setVersion(dependency.getVersion());
				model.addDependency(mavenDependency);
			}
			reader.close();
			if (projectData.getProperties() != null) {
				for (Property property : projectData.getProperties().getProperty()) {
					model.addProperty(property.getKey(), property.getValue());
				}
			}
			MavenXpp3Writer xpp3Writer = new MavenXpp3Writer();
			writer = new FileWriter(Configuration.ProjectData.getProjectcreationpath() + "//"
					+ projectData.getProjectName() + "//pom.xml");
			xpp3Writer.write(writer, model);
			writer.close();
		} finally {
			reader.close();
			writer.close();
		}
	}

	private List<JavaFile> buildJavaClasses(Microservice ProjectData) throws Exception {

		ControllerBuilder controllerBuilder=new ControllerBuilder();
		ConfigurationBuilder configBuilder=new ConfigurationBuilder();
		ServiceBuilder serivceBuilder = new ServiceBuilder();
		DAOBuilder daoBuilder = new DAOBuilder();
		ModelBuilder modelBuilder = new ModelBuilder();
		MessageBuilder messageBuilder = new MessageBuilder();
		ExceptionBuilder exceptionBuilder = new ExceptionBuilder();
		List<JavaFile> javaFiles=new ArrayList<JavaFile>();	
		createBasicProjectFolder(ProjectData);

		if(ProjectData.getControllers()!=null)
		{
			for(TypeSpec controllerClass : controllerBuilder.getControllerClass(ProjectData.getControllers()))
			{
				javaFiles.add(JavaFile.builder(ProjectData.getBasePackage()+"."+ProjectData.getControllers().getPackagename(), controllerClass).build());
			}
		}
		if(ProjectData.getConfigurations()!=null)
		{
			for(TypeSpec configClass : configBuilder.getConfigClass(ProjectData.getConfigurations()))
			{
				javaFiles.add(JavaFile.builder(ProjectData.getBasePackage()+"."+ProjectData.getConfigurations().getPackagename(), configClass).build());
			}
		}
		if(ProjectData.getService()!=null)
		{
			for(TypeSpec configClass : serivceBuilder.getServiceClasses(ProjectData.getService()))
			{
				javaFiles.add(JavaFile.builder(ProjectData.getBasePackage()+"."+ProjectData.getService().getPackagename(), configClass).build());
			}
		}
		if(ProjectData.getBackendIntegration()!=null && ProjectData.getBackendIntegration().getDao()!=null)
		{
			for(TypeSpec configClass : daoBuilder.getServiceClasses(ProjectData.getBackendIntegration().getDao()))
			{
				javaFiles.add(JavaFile.builder(ProjectData.getBasePackage()+"."+ProjectData.getBackendIntegration().getDao().getPackagename(), configClass).build());
			}
		}
		if(ProjectData.getModels()!=null)
		{
			for(TypeSpec modelClass : modelBuilder.getModelClasses(ProjectData.getModels()))
			{
				javaFiles.add(JavaFile.builder(ProjectData.getBasePackage()+"."+ProjectData.getModels().getPackagename(), modelClass).build());
			}
		}
		if(ProjectData.getBackendIntegration()!=null && ProjectData.getBackendIntegration().getMessaging()!=null)
		{
			for(TypeSpec handlerClass : messageBuilder.getHandlerClasses(ProjectData.getBackendIntegration().getMessaging()))
			{
				javaFiles.add(JavaFile.builder(ProjectData.getBasePackage()+"."+ProjectData.getBackendIntegration().getMessaging().getPackagename(), handlerClass).build());
			}
			if(ProjectData.getBackendIntegration().getMessaging().getBrokers()!=null)
			{
				for(TypeSpec brokerClass : messageBuilder.getBrokerClasses(ProjectData.getBackendIntegration().getMessaging().getBrokers()))
				{
					javaFiles.add(JavaFile.builder(ProjectData.getBasePackage()+"."+ProjectData.getBackendIntegration().getMessaging().getPackagename(), brokerClass).build());
				}
			}
		}
		if(ProjectData.getBackendIntegration()!=null && ProjectData.getBackendIntegration().getDao()!=null && ProjectData.getBackendIntegration().getDao().getDatabases()!=null)
		{
			for(TypeSpec databaseClass : daoBuilder.getDataBaseClasses(ProjectData.getBackendIntegration().getDao().getDatabases()))
			{
				javaFiles.add(JavaFile.builder(ProjectData.getBasePackage()+"."+ProjectData.getBackendIntegration().getDao().getPackagename(), databaseClass).build());
			}
		}
		TypeSpec exceptionHandlingClass = exceptionBuilder.getExceptionHandlingClass();
		javaFiles.add(JavaFile.builder(ProjectData.getBasePackage()+TypeConstants.EXCEPTION_PACKAGE, exceptionHandlingClass).build());

		return javaFiles;
	}

	private void addCommandPropertiesFile(String resourcesPath, Microservice projectData) throws Exception {
		OutputStream outputStream = new FileOutputStream(resourcesPath + "//application.properties");

		try {
			List<String> propertyFiles = new ArrayList<String>();
			if (projectData.getBackendIntegration() != null
					&& projectData.getBackendIntegration().getMessaging() != null
					&& projectData.getBackendIntegration().getMessaging().getBrokers() != null
					&& projectData.getBackendIntegration().getMessaging().getBrokers().getBroker() != null
					&& projectData.getBackendIntegration().getMessaging().getBrokers().getBroker().get(0).getType()
					.equalsIgnoreCase("kafka")) {
				propertyFiles.add("kafka.properties");
			}
			if (projectData.getBackendIntegration() != null && projectData.getBackendIntegration().getDao() != null
					&& projectData.getBackendIntegration().getDao().getDatabases() != null
					&& projectData.getBackendIntegration().getDao().getDatabases().getDatabase() != null
					&& projectData.getBackendIntegration().getDao().getDatabases().getDatabase().get(0) != null
					&& projectData.getBackendIntegration().getDao().getDatabases().getDatabase().get(0).getType()
					.equalsIgnoreCase("MongoDataBase")) {
				propertyFiles.add("mongodatabase.properties");
			}
			if (projectData.getBackendIntegration() != null && projectData.getBackendIntegration().getDao() != null
					&& projectData.getBackendIntegration().getDao().getDatabases() != null
					&& projectData.getBackendIntegration().getDao().getDatabases().getDatabase() != null
					&& projectData.getBackendIntegration().getDao().getDatabases().getDatabase().get(0) != null
					&& projectData.getBackendIntegration().getDao().getDatabases().getDatabase().get(0).getType()
					.equalsIgnoreCase("MySql")) {
				propertyFiles.add("mysql.properties");
			}
			if (projectData.getBackendIntegration() != null && projectData.getBackendIntegration().getDao() != null
					&& projectData.getBackendIntegration().getDao().getDatabases() != null
					&& projectData.getBackendIntegration().getDao().getDatabases().getDatabase() != null
					&& projectData.getBackendIntegration().getDao().getDatabases().getDatabase().get(0) != null
					&& projectData.getBackendIntegration().getDao().getDatabases().getDatabase().get(0).getType()
					.equalsIgnoreCase("OracleDB")) {
				propertyFiles.add("oracledb.properties");
			}
			propertyFiles.add("microservice.properties");
			for (String fileName : propertyFiles) {
				ClassLoader classLoader = getClass().getClassLoader();
				InputStream input = classLoader.getResourceAsStream(fileName);
				Properties inputFile = new Properties();
				inputFile.load(input);
				Properties outputFile = new Properties();
				for (String keys : inputFile.stringPropertyNames()) {
					outputFile.setProperty(keys, "");
				}
				outputFile.store(outputStream, null);
				outputFile.load(input);
				input.close();
			}
		} catch (IOException ex) {
			ex.printStackTrace();
			throw new Exception("Cannot Hit url spring.io");
		} finally {
			outputStream.close();
		}
	}

	public void createBasicProjectFolder(Microservice intializerObject) throws Exception {
		String projectName = intializerObject.getProjectName();
		ProjectSpringDependencies depencies = intializerObject.getProjectSpringDependencies();
		List<com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.ProjectSpringDependencies.Dependency> dependecyList = depencies
				.getDependency();
		String dependencyString = " -d=" + dependecyList.get(0).getArtifactId();
		String packageNameString = " -package=" + TypeConstants.BASE_PACKAGE;
		String packagingTypeString = " -p=" + intializerObject.getPackagingType();
		String artifactId = " -a=" + projectName;
		String groupId = " -g=" + intializerObject.getBasePackage();
		String applicationName = " -n=" + intializerObject.getProjectName();
		String projectVersion = " -v=" + intializerObject.getProjectversion();
		String springBootVersion = " --boot-version="+intializerObject.getSpringbootversion();

		for (com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.ProjectSpringDependencies.Dependency dependency : dependecyList
				.subList(1, dependecyList.size())) {
			dependencyString = dependencyString.concat("," + dependency.getArtifactId());
		}

		String command = Configuration.ProjectData.getSpringbootclipath() + "//spring.bat init" + dependencyString
				+ applicationName + artifactId + groupId + projectVersion + packageNameString+ springBootVersion + packagingTypeString
				+ " --force " + projectName;
		LOG.info(command);
		Runtime rt = Runtime.getRuntime();
		java.lang.Process pr;
		try {
			pr = rt.exec(command, null, new File(intializerObject.getProjectcreationpath()));

			BufferedReader input = new BufferedReader(new InputStreamReader(pr.getInputStream()));

			String line = null;
			while ((line = input.readLine()) != null) {
				LOG.info(line);
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

	}
}
