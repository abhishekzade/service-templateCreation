package com.capgemini.cfs.coe.microservicetemplate.writer;

import java.util.ArrayList;
import java.util.List;

import javax.lang.model.element.Modifier;

import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Brokers;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Brokers.Broker;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Brokers.Broker.Consumer;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Brokers.Broker.Producer;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Brokers.Broker.Producer.Fields;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Brokers.Broker.Producer.Methods.Method;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Brokers.Broker.Producer.Methods.Method.Annotation;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Brokers.Broker.Producer.Methods.Method.Parameters;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Brokers.Broker.Producer.Methods.Method.Annotation.Members.Member;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Brokers.Broker.Producer.Methods.Method.Parameters.Parameter;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Implementations.Implementation;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Implementations.Implementation.Fields.Field;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Interfaces.Interface;
import com.capgemini.cfs.coe.microservicetemplate.util.TypeConstants;
import com.squareup.javapoet.AnnotationSpec;
import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.FieldSpec;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.ParameterSpec;
import com.squareup.javapoet.TypeName;
import com.squareup.javapoet.TypeSpec;

public class MessageBuilder {

	public List<TypeSpec> getHandlerClasses(Messaging messaging) {
		List<TypeSpec> handlerClasses=new ArrayList<TypeSpec>();
		for(Interface interfaceClass : messaging.getInterfaces().getInterface())
		{
			TypeSpec handlerClass=TypeSpec.interfaceBuilder(interfaceClass.getInterfacename())
					.addModifiers(Modifier.PUBLIC)
					.addAnnotation(org.springframework.stereotype.Service.class)
					.addMethods(createHandlerMethods(interfaceClass))
					.build();
			handlerClasses.add(handlerClass);
		}
		for(Implementation implementation : messaging.getImplementations().getImplementation())
		{
			if(implementation.getImplements()!=null)
			{
				if(implementation.getFields()!=null)
				{
					TypeSpec implementaionClasses = TypeSpec.classBuilder(implementation.getClassname())
							.addModifiers(Modifier.PUBLIC)
							.addAnnotation(org.springframework.stereotype.Service.class)
							.addFields(createFields(implementation))
							.addSuperinterface(ClassName.get("",implementation.getImplements()))
							.addMethods(addSuperInterfaceMethods(messaging,implementation.getImplements()))
							.build();
					handlerClasses.add(implementaionClasses);
				}
				else
				{
					TypeSpec implementaionClasses = TypeSpec.classBuilder(implementation.getClassname())
							.addModifiers(Modifier.PUBLIC)
							.addAnnotation(org.springframework.stereotype.Service.class)
							.addSuperinterface(ClassName.get("",implementation.getImplements()))
							.addMethods(addSuperInterfaceMethods(messaging,implementation.getImplements()))
							.build();
					handlerClasses.add(implementaionClasses);
				}
			}
			else
			{
				if(implementation.getFields()!=null)
				{
					TypeSpec implementaionClasses = TypeSpec.classBuilder(implementation.getClassname())
							.addModifiers(Modifier.PUBLIC)
							.addAnnotation(org.springframework.stereotype.Service.class)
							.addFields(createFields(implementation))
							.build();
					handlerClasses.add(implementaionClasses);
				}
				else
				{
					TypeSpec implementaionClasses = TypeSpec.classBuilder(implementation.getClassname())
							.addModifiers(Modifier.PUBLIC)
							.addAnnotation(org.springframework.stereotype.Service.class)
							.build();
					handlerClasses.add(implementaionClasses);
				}
			}
		}
		return handlerClasses;
	}

	private Iterable<MethodSpec> addSuperInterfaceMethods(Messaging messaging, String implements1) {

		List<MethodSpec> methodSpecs = new ArrayList<MethodSpec>();
		for(Interface interface1 : messaging.getInterfaces().getInterface())
		{
			if(interface1.getInterfacename().equalsIgnoreCase(implements1))
			{
				if(interface1.getMethods()!=null && interface1.getMethods().getMethod()!=null)
				{
					for(com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Interfaces.Interface.Methods.Method method : interface1.getMethods().getMethod())
					{
						methodSpecs.add(
								MethodSpec.methodBuilder(method.getName())
								.addModifiers(Modifier.PUBLIC)
								.addAnnotation(Override.class)
								.addParameters(getParameters(method.getParameters()))
								.addStatement("// TODO Auto-generated method stub")
								.build());
					}
				}
			}
		}

		return methodSpecs;
	}

	private Iterable<MethodSpec> createHandlerMethods(Interface interfaceClass) {
		List<MethodSpec> methodSpecs = new ArrayList<MethodSpec>();
		if(interfaceClass.getMethods()!=null)
		{
			for(com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Interfaces.Interface.Methods.Method method : interfaceClass.getMethods().getMethod())
			{

				methodSpecs.add(MethodSpec.methodBuilder(method.getName())
						.addModifiers(Modifier.PUBLIC, Modifier.ABSTRACT)
						.addParameters(getParameters(method.getParameters()))
						.build()
						);
			}
		}
		return methodSpecs;
	}

	private Iterable<ParameterSpec> getParameters(
			com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Interfaces.Interface.Methods.Method.Parameters parameters) 
	{
		List<ParameterSpec> methodParams=new ArrayList<ParameterSpec>();
		if(parameters != null && parameters.getParameter()!=null)
		{
			for(com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Interfaces.Interface.Methods.Method.Parameters.Parameter param:parameters.getParameter())
			{
				TypeName modelName=TypeConstants.getType(param.getType());
				methodParams.add(ParameterSpec.builder(modelName,param.getName())
						.build());
			}
		}
		return methodParams;
	}

	private Iterable<FieldSpec> createFields(Implementation implementation) {
		List<FieldSpec> fieldSpecs = new ArrayList<FieldSpec>();
		for(Field field : implementation.getFields().getField())
		{
			fieldSpecs.add(
					FieldSpec.builder(TypeConstants.getDAOClasses(field.getType()), field.getName(), TypeConstants.getModifier(field.getModifier()))
					.addAnnotation(TypeConstants.getAnnotationType(field.getAnnotation()))
					.build());
		}
		return fieldSpecs;
	}

	public List<TypeSpec> getBrokerClasses(Brokers brokers) {
		List<TypeSpec> brokerClasses=new ArrayList<TypeSpec>();
		for(Broker broker : brokers.getBroker())
		{
			if(broker.getProducer()!=null)
			{
				if(broker.getProducer().getFields()!=null && broker.getProducer().getMethods()!=null)
				{
					TypeSpec brokerClass=TypeSpec.classBuilder(broker.getProducer().getName())
							.addModifiers(Modifier.PUBLIC)
							.addMethods(createProducerMethods(broker.getProducer()))
							.addFields(createProducerFields(broker.getProducer().getFields()))
							.addAnnotation(org.springframework.stereotype.Service.class)
							.build();
					brokerClasses.add(brokerClass);
				}
				else if(broker.getProducer().getFields()==null && broker.getProducer().getMethods()!=null)
				{
					TypeSpec brokerClass=TypeSpec.classBuilder(broker.getProducer().getName())
							.addModifiers(Modifier.PUBLIC)
							.addMethods(createProducerMethods(broker.getProducer()))
							.addAnnotation(org.springframework.stereotype.Service.class)
							.build();
					brokerClasses.add(brokerClass);
				}
				else if(broker.getProducer().getFields()!=null && broker.getProducer().getMethods()==null)
				{
					TypeSpec brokerClass=TypeSpec.classBuilder(broker.getProducer().getName())
							.addModifiers(Modifier.PUBLIC)
							.addFields(createProducerFields(broker.getProducer().getFields()))
							.addAnnotation(org.springframework.stereotype.Service.class)
							.build();
					brokerClasses.add(brokerClass);
				}
				else if(broker.getProducer().getFields()==null && broker.getProducer().getMethods()==null)
				{
					TypeSpec brokerClass=TypeSpec.classBuilder(broker.getProducer().getName())
							.addModifiers(Modifier.PUBLIC)
							.addAnnotation(org.springframework.stereotype.Service.class)
							.build();
					brokerClasses.add(brokerClass);
				}
			}
			if(broker.getConsumer()!=null)
			{
				if(broker.getConsumer().getFields()!=null && broker.getConsumer().getMethods()!=null)
				{
					TypeSpec brokerClass=TypeSpec.classBuilder(broker.getConsumer().getName())
							.addModifiers(Modifier.PUBLIC)
							.addMethods(createConsumerMethods(broker.getConsumer()))
							.addFields(createConsumerFields(broker.getConsumer().getFields()))
							.addAnnotation(org.springframework.stereotype.Service.class)
							.build();
					brokerClasses.add(brokerClass);
				}
				else if(broker.getConsumer().getFields()!=null && broker.getConsumer().getMethods()==null)
				{
					TypeSpec brokerClass=TypeSpec.classBuilder(broker.getConsumer().getName())
							.addModifiers(Modifier.PUBLIC)
							.addFields(createConsumerFields(broker.getConsumer().getFields()))
							.addAnnotation(org.springframework.stereotype.Service.class)
							.build();
					brokerClasses.add(brokerClass);
				}
				else if(broker.getConsumer().getFields()==null && broker.getConsumer().getMethods()!=null)
				{
					TypeSpec brokerClass=TypeSpec.classBuilder(broker.getConsumer().getName())
							.addModifiers(Modifier.PUBLIC)
							.addMethods(createConsumerMethods(broker.getConsumer()))
							.addAnnotation(org.springframework.stereotype.Service.class)
							.build();
					brokerClasses.add(brokerClass);
				}
				else if(broker.getConsumer().getFields()==null && broker.getConsumer().getMethods()==null)
				{
					TypeSpec brokerClass=TypeSpec.classBuilder(broker.getConsumer().getName())
							.addModifiers(Modifier.PUBLIC)
							.addAnnotation(org.springframework.stereotype.Service.class)
							.build();
					brokerClasses.add(brokerClass);
				}
			}
		}
		return brokerClasses;
	}

	private Iterable<MethodSpec> createConsumerMethods(Consumer consumer) {

		List<MethodSpec> methodSpecs = new ArrayList<MethodSpec>();
		for(com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Brokers.Broker.Consumer.Methods.Method method : consumer.getMethods().getMethod())
		{
			if(method.getAnnotation()!=null)
			{
				methodSpecs.add(MethodSpec.methodBuilder(method.getName())
						.addModifiers(Modifier.PUBLIC)
						.addAnnotation(getConsumerAnnotation(method.getAnnotation()))
						.addParameters(getConsumerParameters(method.getParameters()))
						.addStatement("// TODO Auto-generated method stub")
						.build()
						);
			}
			else
			{
				methodSpecs.add(MethodSpec.methodBuilder(method.getName())
						.addModifiers(Modifier.PUBLIC)
						.addParameters(getConsumerParameters(method.getParameters()))
						.addStatement("// TODO Auto-generated method stub")
						.build()
						);
			}

		}

		return methodSpecs;
	}

	private Iterable<ParameterSpec> getConsumerParameters(
			com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Brokers.Broker.Consumer.Methods.Method.Parameters parameters) {

		List<ParameterSpec> methodParams=new ArrayList<ParameterSpec>();
		if(parameters != null)
		{
			for(com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Brokers.Broker.Consumer.Methods.Method.Parameters.Parameter param:parameters.getParameter())
			{
				TypeName modelName=TypeConstants.getType(param.getType());
				methodParams.add(ParameterSpec.builder(modelName,param.getName())
						.build());
			}
		}

		return methodParams;
	}

	private AnnotationSpec getConsumerAnnotation(
			com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Brokers.Broker.Consumer.Methods.Method.Annotation annotation) {

		AnnotationSpec annotationSpec = null;
		if(annotation!=null )
		{  
			if(annotation.getMembers()!=null)
			{
				AnnotationSpec.Builder builder = AnnotationSpec.builder(TypeConstants.getAnnotationType(annotation.getName()));
				for(com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Brokers.Broker.Consumer.Methods.Method.Annotation.Members.Member member : annotation.getMembers().getMember())
				{
					builder.addMember(member.getName(), "$S",member.getValue());
				}
				annotationSpec = builder.build();
			}
			else { 
				annotationSpec = AnnotationSpec.builder(TypeConstants.getAnnotationType(annotation.getName()))
						.build();
			}
		}
		return annotationSpec;
	}

	private Iterable<MethodSpec> createProducerMethods(Producer producer) {

		List<MethodSpec> methodSpecs = new ArrayList<MethodSpec>();
		for(Method method : producer.getMethods().getMethod())
		{
			if(method.getAnnotation()!=null)
			{
				methodSpecs.add(MethodSpec.methodBuilder(method.getName())
						.addModifiers(Modifier.PUBLIC)
						.addAnnotation(getProducerAnnotation(method.getAnnotation()))
						.addParameters(getProducerParameters(method.getParameters()))
						.addStatement("// TODO Auto-generated method stub")
						.addStatement("return null")
						.returns(TypeConstants.getType(method.getReturns()))
						.build()
						);
			}
			else
			{
				methodSpecs.add(MethodSpec.methodBuilder(method.getName())
						.addModifiers(Modifier.PUBLIC)
						.addParameters(getProducerParameters(method.getParameters()))
						.addStatement("// TODO Auto-generated method stub")
						.addStatement("return null")
						.returns(TypeConstants.getType(method.getReturns()))
						.build()
						);
			}

		}

		return methodSpecs;
	}

	private Iterable<FieldSpec> createConsumerFields(
			com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Brokers.Broker.Consumer.Fields fields) {
		List<FieldSpec> fieldSpecs = new ArrayList<FieldSpec>();
		for(com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Brokers.Broker.Consumer.Fields.Field field : fields.getField())
		{
			fieldSpecs.add(
					FieldSpec.builder(TypeConstants.getDAOClasses(field.getType()), field.getName(), TypeConstants.getModifier(field.getModifier()))
					.addAnnotation(TypeConstants.getAnnotationType(field.getAnnotation()))
					.build());
		}
		return fieldSpecs;
	}

	private Iterable<FieldSpec> createProducerFields(Fields fields) {

		List<FieldSpec> fieldSpecs = new ArrayList<FieldSpec>();
		for(com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.BackendIntegration.Messaging.Brokers.Broker.Producer.Fields.Field field : fields.getField())
		{
			fieldSpecs.add(
					FieldSpec.builder(TypeConstants.getDAOClasses(field.getType()), field.getName(), TypeConstants.getModifier(field.getModifier()))
					.addAnnotation(TypeConstants.getAnnotationType(field.getAnnotation()))
					.build());
		}
		return fieldSpecs;

	}

	private Iterable<ParameterSpec> getProducerParameters(Parameters parameters) {
		List<ParameterSpec> methodParams=new ArrayList<ParameterSpec>();
		if(parameters != null)
		{
			for(Parameter param:parameters.getParameter())
			{
				TypeName modelName=TypeConstants.getType(param.getType());
				methodParams.add(ParameterSpec.builder(modelName,param.getName())
						.build());
			}
		}

		return methodParams;
	}

	public AnnotationSpec getProducerAnnotation(Annotation annotation){
		AnnotationSpec annotationSpec = null;
		if(annotation!=null )
		{  
			if(annotation.getMembers()!=null)
			{
				AnnotationSpec.Builder builder = AnnotationSpec.builder(TypeConstants.getAnnotationType(annotation.getName()));
				for(Member member : annotation.getMembers().getMember())
				{
					builder.addMember(member.getName(), "$S",member.getValue());
				}
				annotationSpec = builder.build();
			}
			else { 
				annotationSpec = AnnotationSpec.builder(TypeConstants.getAnnotationType(annotation.getName()))
						.build();
			}
		}
		return annotationSpec;
	}

}
