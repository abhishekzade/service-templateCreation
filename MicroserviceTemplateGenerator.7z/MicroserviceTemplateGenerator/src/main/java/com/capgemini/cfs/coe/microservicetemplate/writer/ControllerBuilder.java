package com.capgemini.cfs.coe.microservicetemplate.writer;



import java.util.ArrayList;
import java.util.List;

import javax.lang.model.element.Modifier;

import org.springframework.web.bind.annotation.RestController;

import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Controllers;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Controllers.Controller;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Controllers.Controller.Fields.Field;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Controllers.Controller.Methods.Method;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Controllers.Controller.Methods.Method.Parameters;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Controllers.Controller.Methods.Method.Parameters.Parameter;
import com.capgemini.cfs.coe.microservicetemplate.util.TypeConstants;
import com.squareup.javapoet.AnnotationSpec;
import com.squareup.javapoet.ClassName;
import com.squareup.javapoet.FieldSpec;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.ParameterSpec;
import com.squareup.javapoet.TypeName;
import com.squareup.javapoet.TypeSpec;


public class ControllerBuilder {

	public List<TypeSpec> getControllerClass(Controllers controllers) {
		List<TypeSpec> controllerClasses = new ArrayList<TypeSpec>();
		for(Controller controller : controllers.getController())
		{
			if(controller.getMethods()!=null)
			{
				if(controller.getFields()!=null)
				{
					TypeSpec controllerClass = TypeSpec.classBuilder(controller.getClassname())
							.addModifiers(Modifier.PUBLIC)
							.addAnnotation(AnnotationSpec.builder(RestController.class).build())
							.addFields(createFields(controller))
							.addMethods(controllerMethods(controller))
							.build();
					controllerClasses.add(controllerClass);
				}
				else
				{
					TypeSpec controllerClass = TypeSpec.classBuilder(controller.getClassname())
							.addModifiers(Modifier.PUBLIC)
							.addAnnotation(AnnotationSpec.builder(RestController.class).build())
							.addMethods(controllerMethods(controller))
							.build();
					controllerClasses.add(controllerClass);
				}
			}
			else
			{
				if(controller.getFields()!=null)
				{
					TypeSpec controllerClass = TypeSpec.classBuilder(controller.getClassname())
							.addModifiers(Modifier.PUBLIC)
							.addAnnotation(AnnotationSpec.builder(RestController.class).build())
							.addFields(createFields(controller))
							.build();
					controllerClasses.add(controllerClass);
				}
				else
				{
					TypeSpec controllerClass = TypeSpec.classBuilder(controller.getClassname())
							.addModifiers(Modifier.PUBLIC)
							.addAnnotation(AnnotationSpec.builder(RestController.class).build())
							.build();
					controllerClasses.add(controllerClass);
				}
			}

		}
		return controllerClasses;
	}

	private Iterable<FieldSpec> createFields(Controller controller) {
		List<FieldSpec> fieldSpecs = new ArrayList<FieldSpec>();
		for(Field field : controller.getFields().getField())
		{
			fieldSpecs.add(
					FieldSpec.builder(ClassName.get(TypeConstants.SERVICE_PACKAGE,field.getType()), field.getName(), TypeConstants.getModifier(field.getModifier()))
					.addAnnotation(TypeConstants.getAnnotationType(field.getAnnotation()))
					.build());
		}
		return fieldSpecs;
	}

	private Iterable<MethodSpec> controllerMethods(Controller controller) {
		List<MethodSpec> methodSpecs = new ArrayList<MethodSpec>();
		for(Method method : controller.getMethods().getMethod())
		{

			methodSpecs.add(MethodSpec.methodBuilder(method.getName())
					.addModifiers(Modifier.PUBLIC)
					.addAnnotation(getMappingAnnotation(method))
					.addParameters(getParameters(method.getParameters()))
					.addStatement("// TODO Auto-generated method stub")
					.addStatement("return null")
					.returns(TypeConstants.getType(method.getReturns()))
					.build()
					);
		}

		return methodSpecs;
	}


	private Iterable<ParameterSpec> getParameters(Parameters parameters) {
		List<ParameterSpec> methodParams=new ArrayList<ParameterSpec>();
		if(parameters != null)
		{
			for(Parameter param:parameters.getParameter())
			{
				TypeName modelName=TypeConstants.getType(param.getType());

				methodParams.add(ParameterSpec.builder(modelName,param.getName())
						.addAnnotation(AnnotationSpec.builder(TypeConstants.getAnnotationType(param.getAnnotation())).build())
						.build());
			}
		}

		return methodParams;
	}

	public AnnotationSpec getMappingAnnotation(Method method){
		if(method.getPath()!=null && !method.getPath().equalsIgnoreCase(""))
		{    return AnnotationSpec.builder(TypeConstants.getAnnotationType(method.getMethodtype()))
				.addMember("path","$S", method.getPath())
				.build();
		}else {  return AnnotationSpec.builder(TypeConstants.getAnnotationType(method.getMethodtype()))
				.build();
		}

	}

}
