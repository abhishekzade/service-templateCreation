package com.capgemini.cfs.coe.microservicetemplate.writer;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.lang.model.element.Modifier;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Configurations;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Configurations.Configuration.Methods.Method;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Configurations.Configuration.Methods.Method.Parameters;
import com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Configurations.Configuration.Methods.Method.Parameters.Parameter;
import com.capgemini.cfs.coe.microservicetemplate.util.TypeConstants;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.ParameterSpec;
import com.squareup.javapoet.ParameterizedTypeName;
import com.squareup.javapoet.TypeSpec;

import ch.qos.logback.classic.PatternLayout;
import ch.qos.logback.classic.spi.ILoggingEvent;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

public class ConfigurationBuilder {

	public List<TypeSpec> getConfigClass(Configurations configs) {

		List<TypeSpec> configClasses=new ArrayList<TypeSpec>();
		for(com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Configurations.Configuration config : configs.getConfiguration())
		{
			if(config.getMethods()!=null)
			{
				TypeSpec configClass = TypeSpec.classBuilder(config.getClassname())
						.addModifiers(Modifier.PUBLIC)
						.addAnnotation(Configuration.class)
						.addMethods(createConfigMethods(config))
						.build();
				configClasses.add(configClass);
			}
			else
			{
				TypeSpec configClass = TypeSpec.classBuilder(config.getClassname())
						.addModifiers(Modifier.PUBLIC)
						.addAnnotation(Configuration.class)
						.build();
				configClasses.add(configClass);
			}
		}
		//Adding LogConfig and SwaggerConfig Configuration file
		configClasses.add(
				TypeSpec.classBuilder("LogConfig")
				.addModifiers(Modifier.PUBLIC)
				.addAnnotation(Configuration.class)
				.superclass(PatternLayout.class)
				.addField(String.class, "patternsProperty",Modifier.PRIVATE)
				.addField(ParameterizedTypeName.get(Optional.class, Pattern.class), "pattern", Modifier.PRIVATE)
				.addMethods(createLogConfigMethods("LogConfig"))
				.build()
				);
		configClasses.add(
				TypeSpec.classBuilder("SwaggerConfig")
				.addModifiers(Modifier.PUBLIC)
				.addAnnotation(Configuration.class)
				.addAnnotation(EnableSwagger2.class)
				.addMethods(createLogConfigMethods("SwaggerConfig"))
				.build());
		return configClasses;
	}
	private Iterable<MethodSpec> createLogConfigMethods(String className) {
		List<MethodSpec> methodsList=new ArrayList<MethodSpec>();
		if(className.equalsIgnoreCase("LogConfig"))
		{
			MethodSpec getterMethod=MethodSpec.methodBuilder("getPatternsProperty")
					.returns(String.class)
					.addStatement("return patternsProperty")
					.build();
			methodsList.add(getterMethod);
			MethodSpec setterMethod=MethodSpec.methodBuilder("setPatternsProperty")
					.addParameter(ParameterSpec.builder(String.class , "patternsProperty").build())
					.addStatement("this.patternsProperty = patternsProperty;\r\n" + 
							"		if (this.patternsProperty != null) {\r\n" + 
							"			this.pattern = Optional.of(Pattern.compile(patternsProperty, Pattern.MULTILINE));\r\n" + 
							"		} else {\r\n" + 
							"			this.pattern = Optional.empty();\r\n" + 
							"		}")
					.build();
			methodsList.add(setterMethod);
			MethodSpec repoMethod=MethodSpec.methodBuilder("doLayout")
					.addAnnotation(Override.class)
					.addModifiers(Modifier.PUBLIC)
					.returns(String.class)
					.addParameter(ParameterSpec.builder(ILoggingEvent.class , "event").build())
					.addStatement("final StringBuilder message = new StringBuilder(super.doLayout(event));")
					.addStatement("$T matcher", Matcher.class)
					.addStatement("if (pattern.isPresent()) {\r\n" + 
							"			matcher = pattern.get().matcher(message);\r\n" + 
							"			while (matcher.find()) {\r\n" + 
							"\r\n" + 
							"				int group = 1;\r\n" + 
							"				while (group <= matcher.groupCount()) {\r\n" + 
							"					if (matcher.group(group) != null) {\r\n" + 
							"						for (int i = matcher.start(group); i < matcher.end(group); i++) {\r\n" + 
							"							message.setCharAt(i, '*');\r\n" + 
							"						}\r\n" + 
							"					}\r\n" + 
							"					group++;\r\n" + 
							"				}\r\n" + 
							"			}\r\n" + 
							"		}")
					.addStatement("return message.toString()")
					.build();
			methodsList.add(repoMethod);
		}
		if(className.equalsIgnoreCase("SwaggerConfig")) { 
			MethodSpec apiMethod=MethodSpec.methodBuilder("api")
					.addAnnotation(Bean.class)
					.addModifiers(Modifier.PUBLIC)
					.returns(Docket.class)
					.addStatement("return new Docket($T.SWAGGER_2).select().apis($T.any()).paths($T.any()).build()",DocumentationType.class,RequestHandlerSelectors.class,PathSelectors.class)
					.build(); 
			methodsList.add(apiMethod); 
		}

		return methodsList;
	}
	private Iterable<MethodSpec> createConfigMethods(com.capgemini.cfs.coe.microservicetemplate.jaxbclasses.Microservice.Configurations.Configuration config) {
		List<MethodSpec> methodsList=new ArrayList<MethodSpec>();
		for(Method method : config.getMethods().getMethod())
		{
			if(method.getParameters()!=null)
			{
				MethodSpec repoMethod=MethodSpec.methodBuilder(method.getName().toString())
						.addModifiers(Modifier.PUBLIC)
						.returns(TypeConstants.getType(method.getReturns()))
						.addParameters(createParameters(method.getParameters()))
						.addStatement("// TODO Auto-generated method stub")
						.addStatement("return null")
						.build();
				methodsList.add(repoMethod);	
			}
			else
			{
				MethodSpec repoMethod=MethodSpec.methodBuilder(method.getName())
						.addModifiers(Modifier.PUBLIC)
						.returns(TypeConstants.getType(method.getReturns()))
						.addStatement("// TODO Auto-generated method stub")
						.addStatement("return null")
						.build();
				methodsList.add(repoMethod);
			}
		}

		return methodsList;
	}
	private Iterable<ParameterSpec> createParameters(Parameters parameters) {
		List<ParameterSpec> parameterSpecs = new ArrayList<ParameterSpec>();
		for(Parameter parameter : parameters.getParameter())
		{
			ParameterSpec parameterSpec = ParameterSpec.builder(TypeConstants.getType(parameter.getType()), parameter.getName()).build();
			parameterSpecs.add(parameterSpec);
		}
		return parameterSpecs;
	}

}
